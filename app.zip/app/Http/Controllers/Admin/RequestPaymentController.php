<?php

namespace App\Http\Controllers\Admin;

use App\DataTables\Admin\RequestPaymentsDataTable;
use App\Http\Controllers\Users\EmailController;
use App\Exports\RequestPaymentsExport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use Session, Config, Common;
use Illuminate\Http\Request;
use App\Models\{Transaction,
    RequestPayment,
    EmailTemplate,
    Wallet,
    User
};

class RequestPaymentController extends Controller
{
    protected $helper;
    protected $email;
    protected $requestpayment;

    public function __construct()
    {
        $this->helper         = new Common();
        $this->email          = new EmailController();
        $this->requestpayment = new RequestPayment();
    }

    public function index(RequestPaymentsDataTable $dataTable)
    {
        $data['menu']     = 'transaction';
        $data['sub_menu'] = 'request_payments';

        $data['requestpayments_status']     = $this->requestpayment->select('status')->groupBy('status')->get();
        $data['requestpayments_currencies'] = $this->requestpayment->select('currency_id')->groupBy('currency_id')->get();

        $data['from']     = isset(request()->from) ? setDateForDb(request()->from) : null;
        $data['to']       = isset(request()->to ) ? setDateForDb(request()->to) : null;
        $data['status']   = isset(request()->status) ? request()->status : 'all';
        $data['currency'] = isset(request()->currency) ? request()->currency : 'all';
        $data['user']     = $user    = isset(request()->user_id) ? request()->user_id : null;
        $data['getName']  = $this->requestpayment->getRequestPaymentsUserName($user);

        return $dataTable->render('admin.RequestPayment.list', $data);
    }

    public function requestpaymentCsv()
    {
        return Excel::download(new RequestPaymentsExport(), 'requestpayments_list_' . time() . '.xlsx');
    }

    public function requestpaymentPdf()
    {
        $from     = !empty(request()->startfrom) ? setDateForDb(request()->startfrom) : null;
        $to       = !empty(request()->endto) ? setDateForDb(request()->endto) : null;
        $status   = isset(request()->status) ? request()->status : null;
        $currency = isset(request()->currency) ? request()->currency : null;
        $user     = isset(request()->user_id) ? request()->user_id : null;

        $data['requestpayments'] = $this->requestpayment->getRequestPaymentsList($from, $to, $status, $currency, $user)->orderBy('request_payments.id', 'desc')->get();

        if (isset($from) && isset($to)) {
            $data['date_range'] = $from . ' To ' . $to;
        } else {
            $data['date_range'] = 'N/A';
        }

        $mpdf = new \Mpdf\Mpdf(['tempDir' => __DIR__ . '/tmp']);
        $mpdf = new \Mpdf\Mpdf([
            'mode'        => 'utf-8',
            'format'      => 'A3',
            'orientation' => 'P',
        ]);

        $mpdf->autoScriptToLang = true;
        $mpdf->autoLangToFont = true;
        $mpdf->allow_charset_conversion = false;

        $mpdf->WriteHTML(view('admin.RequestPayment.requestpayments_report_pdf', $data));
        $mpdf->Output('requestpayments_report_' . time() . '.pdf', 'D');
    }

    public function requestpaymentsUserSearch(Request $request)
    {
        $search = $request->search;
        $user   = $this->requestpayment->getRequestPaymentsUsersResponse($search);

        $res = [
            'status' => 'fail',
        ];
        if (count($user) > 0)
        {
            $res = [
                'status' => 'success',
                'data'   => $user,
            ];
        }
        return json_encode($res);
    }

    public function edit($id)
    {
        $data['menu']     = 'transaction';
        $data['sub_menu'] = 'request_payments';

        $data['request_payments'] = $request_payments = RequestPayment::find($id);

        $data['transactionOfRefunded'] = $transactionOfRefunded = Transaction::select('refund_reference')->where(['uuid' => $request_payments->uuid])->first();

        $data['requestPaymentsOfRefunded'] = RequestPayment::where(['uuid' => $transactionOfRefunded->refund_reference])->first(['id']);

        $data['transaction'] = Transaction::select('transaction_type_id', 'status', 'percentage', 'charge_percentage', 'charge_fixed', 'transaction_reference_id', 'user_type')
            ->where([
                'transaction_reference_id' => $request_payments->id,
                'status'                   => $request_payments->status,
                'transaction_type_id'      => Request_To,
            ])
            ->first();

        return view('admin.RequestPayment.edit', $data);
    }

    public function update(Request $request)
    {
        $userInfo = User::where(['email' => trim($request->request_payments_email)])->first();

        $englishSenderLanginfoForRPSucRef = EmailTemplate::where(['temp_id' => 8, 'lang' => 'en', 'type' => 'email'])->select('subject', 'body')->first();//if other language's subject and body not set, get en sub and body for mail

        $englishSenderLanginfoForRPCancelPending = EmailTemplate::where(['temp_id' => 16, 'lang' => 'en', 'type' => 'email'])->select('subject', 'body')->first();

        /**
         * SMS
         */
        $rp_status_en_sms_info_suc_ref = EmailTemplate::where(['temp_id' => 8, 'lang' => 'en', 'type' => 'sms'])->select('subject', 'body')->first();
        $rp_status_sms_info_suc_ref = EmailTemplate::where(['temp_id' => 8, 'language_id' => Session::get('default_language'), 'type' => 'sms'])->select('subject', 'body')->first();

        $rp_status_en_sms_info_canc_pend = EmailTemplate::where(['temp_id' => 16, 'lang' => 'en', 'type' => 'sms'])->select('subject', 'body')->first();
        $rp_status_sms_info_canc_pend = EmailTemplate::where(['temp_id' => 16, 'language_id' => Session::get('default_language'), 'type' => 'sms'])->select('subject', 'body')->first();


        //Updating both Request_From and Request_To entries by using one type
        if ($request->transaction_type == 'Request_To')
        {
            if ($request->status == 'Success')
            {
                if ($request->transaction_status == 'Success') //current status
                {
                    $this->helper->one_time_message('success', __('The :x status is already :y.', ['x' => __('request payment'), 'y' => __('successful')]));
                    return redirect(Config::get('adminPrefix').'/request_payments');
                }
            }
            elseif ($request->status == 'Refund')
            {
                if ($request->transaction_status == 'Refund') //current status
                {
                    $this->helper->one_time_message('success', __('The :x status is already :y.', ['x' => __('request payment'), 'y' => __('refunded')]));
                    return redirect(Config::get('adminPrefix').'/request_payments');
                }
                elseif ($request->transaction_status == 'Success') //done
                {
                    $unique_code = unique_code();

                    $requestpayment = new RequestPayment();

                    $requestpayment->user_id = $request->user_id;

                    $requestpayment->receiver_id = isset($userInfo) ? $userInfo->id : null;

                    $requestpayment->currency_id = $request->currency_id;

                    $requestpayment->uuid = $unique_code;

                    $requestpayment->amount = $request->amount;

                    $requestpayment->accept_amount = $request->accept_amount;

                    $requestpayment->email = $request->request_payments_email;

                    $requestpayment->note = $request->note;

                    $requestpayment->status = $request->status;
                    
                    $requestpayment->save();

                    //Transferred entry update
                    Transaction::where([
                        'user_id'                  => $request->user_id,
                        'end_user_id'              => isset($userInfo) ? $userInfo->id : null,
                        'transaction_reference_id' => $request->transaction_reference_id,
                        'transaction_type_id'      => Request_From,
                    ])->update([
                        'refund_reference' => $unique_code,
                    ]);

                    //Received entry update
                    Transaction::where([
                        'user_id'                  => isset($userInfo) ? $userInfo->id : null,
                        'end_user_id'              => $request->user_id,
                        'transaction_reference_id' => $request->transaction_reference_id,
                        'transaction_type_id'      => $request->transaction_type_id,
                    ])->update([
                        'refund_reference' => $unique_code,
                    ]);

                    //New Request_From entry
                    $refund_t_A = new Transaction();

                    $refund_t_A->user_id     = $request->user_id;
                    $refund_t_A->end_user_id = isset($userInfo) ? $userInfo->id : null;
                    $refund_t_A->currency_id = $request->currency_id;
                    $refund_t_A->uuid = $unique_code;
                    $refund_t_A->refund_reference = $request->uuid;
                    $refund_t_A->transaction_reference_id = $requestpayment->id;
                    $refund_t_A->transaction_type_id      = Request_From; //Request_From
                    $refund_t_A->user_type = $request->user_type;
                    $refund_t_A->subtotal = $request->accept_amount;
                    $refund_t_A->percentage = 0;
                    $refund_t_A->charge_percentage = 0;
                    $refund_t_A->charge_fixed = 0;
                    $refund_t_A->total = '-' . $refund_t_A->subtotal;
                    $refund_t_A->note   = $request->note;
                    $refund_t_A->status = $request->status;
                    $refund_t_A->save();

                    //New Request_To entry
                    $refund_t_B = new Transaction();

                    $refund_t_B->user_id     = isset($userInfo) ? $userInfo->id : null;
                    $refund_t_B->end_user_id = $request->user_id;

                    $refund_t_B->currency_id              = $request->currency_id;
                    $refund_t_B->uuid                     = $unique_code;
                    $refund_t_B->refund_reference         = $request->uuid;
                    $refund_t_B->transaction_reference_id = $requestpayment->id;

                    $refund_t_B->transaction_type_id = $request->transaction_type_id; //Request_To

                    $refund_t_B->user_type = $request->user_type;
                    // $refund_t_B->email               = $request->request_payments_email;

                    $refund_t_B->subtotal = $request->accept_amount;

                    $refund_t_B->percentage        = $request->percentage;
                    $refund_t_B->charge_percentage = $request->charge_percentage;
                    $refund_t_B->charge_fixed      = $request->charge_fixed;

                    $refund_t_B->total = ($request->charge_percentage + $request->charge_fixed + $refund_t_B->subtotal);

                    $refund_t_B->note = $request->note;

                    $refund_t_B->status = $request->status;

                    $refund_t_B->save();

                    //sender wallet entry update
                    $request_created_wallet = Wallet::where([
                        'user_id'     => $requestpayment->user_id,
                        'currency_id' => $request->currency_id,
                    ])->select('balance')->first();

                    Wallet::where([
                        'user_id'     => $requestpayment->user_id,
                        'currency_id' => $request->currency_id,
                    ])->update([
                        'balance' => $request_created_wallet->balance - $request->accept_amount,
                    ]);

                    if (isset($userInfo))
                    {
                        //receiver wallet entry update
                        $request_accepted_wallet = Wallet::where([
                            'user_id'     => isset($userInfo) ? $userInfo->id : null,
                            'currency_id' => $request->currency_id,
                        ])->select('balance')->first();

                        Wallet::where([
                            'user_id'     => isset($userInfo) ? $userInfo->id : null,
                            'currency_id' => $request->currency_id,
                        ])->update([
                            'balance' => $request_accepted_wallet->balance + ($request->accept_amount + $request->charge_percentage + $request->charge_fixed),
                        ]);
                    }

                    // Sent Mail when request is 'refunded'
                    $t_ref_mail_info = EmailTemplate::where([
                        'temp_id'     => 8,
                        'language_id' => Session::get('default_language'),
                        'type' => 'email',
                    ])->select('subject', 'body')->first();

                    // Creator Mail
                    if (!empty($t_ref_mail_info->subject) && !empty($t_ref_mail_info->body))
                    {
                        // subject
                        $t_ref_sub_1 = str_replace('{uuid}', $requestpayment->uuid, $t_ref_mail_info->subject);
                        // body
                        $t_ref_msg_1 = str_replace('{user_id/receiver_id}', $requestpayment->user->first_name . ' ' . $requestpayment->user->last_name, $t_ref_mail_info->body);
                    }
                    else
                    {
                        // subject
                        $t_ref_sub_1 = str_replace('{uuid}', $requestpayment->uuid, $englishSenderLanginfoForRPSucRef->subject);
                        // body
                        $t_ref_msg_1 = str_replace('{user_id/receiver_id}', $requestpayment->user->first_name . ' ' . $requestpayment->user->last_name, $englishSenderLanginfoForRPSucRef->body);
                    }
                    //1
                    $t_ref_msg_1 = str_replace('{uuid}', $requestpayment->uuid, $t_ref_msg_1);
                    $t_ref_msg_1 = str_replace('{status}', ($requestpayment->status == 'Blocked') ? "Cancelled" : (($requestpayment->status == 'Refund') ? "Refunded" : $requestpayment->status), $t_ref_msg_1);
                    $t_ref_msg_1 = str_replace('{amount}', moneyFormat(optional($requestpayment->currency)->symbol, formatNumber($request->accept_amount)), $t_ref_msg_1);
                    $t_ref_msg_1 = str_replace('{added/subtracted}', 'subtracted', $t_ref_msg_1);
                    $t_ref_msg_1 = str_replace('{from/to}', 'from', $t_ref_msg_1);
                    $t_ref_msg_1 = str_replace('{soft_name}', settings('name'), $t_ref_msg_1);

                    if (checkAppMailEnvironment())
                    {
                        $this->email->sendEmail($requestpayment->user->email, $t_ref_sub_1, $t_ref_msg_1);
                    }

                    //sms
                    if (!empty($requestpayment->user->carrierCode) && !empty($requestpayment->user->phone))
                    {
                        if (!empty($rp_status_sms_info_suc_ref->subject) && !empty($rp_status_sms_info_suc_ref->body))
                        {
                            $rp_status_sms_info_suc_ref_sub = str_replace('{uuid}', $requestpayment->uuid, $rp_status_sms_info_suc_ref->subject);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{user_id/receiver_id}', $requestpayment->user->first_name . ' ' . $requestpayment->user->last_name, $rp_status_sms_info_suc_ref->body);
                        }
                        else
                        {
                            $rp_status_sms_info_suc_ref_sub = str_replace('{uuid}', $requestpayment->uuid, $rp_status_en_sms_info_suc_ref->subject);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{user_id/receiver_id}', $requestpayment->user->first_name . ' ' . $requestpayment->user->last_name, $rp_status_en_sms_info_suc_ref->body);
                        }
                        //2
                        $rp_status_sms_info_suc_ref_msg = str_replace('{uuid}', $requestpayment->uuid, $rp_status_sms_info_suc_ref_msg);
                        $rp_status_sms_info_suc_ref_msg = str_replace('{status}', ($requestpayment->status == 'Blocked') ? "Cancelled" : (($requestpayment->status == 'Refund') ? "Refunded" : $requestpayment->status),
                            $rp_status_sms_info_suc_ref_msg);
                        $rp_status_sms_info_suc_ref_msg = str_replace('{amount}', moneyFormat(optional($requestpayment->currency)->symbol, formatNumber($request->accept_amount)), $rp_status_sms_info_suc_ref_msg);
                        $rp_status_sms_info_suc_ref_msg = str_replace('{added/subtracted}', 'subtracted', $rp_status_sms_info_suc_ref_msg);
                        $rp_status_sms_info_suc_ref_msg = str_replace('{from/to}', 'from', $rp_status_sms_info_suc_ref_msg);

                        if (checkAppSmsEnvironment())
                        {
                            sendSMS($requestpayment->user->carrierCode . $requestpayment->user->phone, $rp_status_sms_info_suc_ref_msg);
                        }
                    }

                    if (isset($userInfo))
                    {
                        // Acceptor Mail
                        if (!empty($t_ref_mail_info->subject) && !empty($t_ref_mail_info->body))
                        {
                            // subject
                            $t_ref_sub_2 = str_replace('{uuid}', $requestpayment->uuid, $t_ref_mail_info->subject);
                            // body
                            $t_ref_msg_2 = str_replace('{user_id/receiver_id}', $requestpayment->receiver->first_name . ' ' . $requestpayment->receiver->last_name, $t_ref_mail_info->body);
                        }
                        else
                        {
                            // subject
                            $t_ref_sub_2 = str_replace('{uuid}', $requestpayment->uuid, $englishSenderLanginfoForRPSucRef->subject);
                            // body
                            $t_ref_msg_2 = str_replace('{user_id/receiver_id}', $requestpayment->receiver->first_name . ' ' . $requestpayment->receiver->last_name, $englishSenderLanginfoForRPSucRef->body);
                        }
                        //3
                        $t_ref_msg_2 = str_replace('{uuid}', $requestpayment->uuid, $t_ref_msg_2);
                        $t_ref_msg_2 = str_replace('{status}', ($requestpayment->status == 'Blocked') ? "Cancelled" : (($requestpayment->status == 'Refund') ? "Refunded" : $requestpayment->status), $t_ref_msg_2);
                        $t_ref_msg_2 = str_replace('{amount}', moneyFormat(optional($requestpayment->currency)->symbol, formatNumber($request->accept_amount + $request->charge_percentage + $request->charge_fixed)), $t_ref_msg_2);
                        $t_ref_msg_2 = str_replace('{added/subtracted}', 'added', $t_ref_msg_2);
                        $t_ref_msg_2 = str_replace('{from/to}', 'to', $t_ref_msg_2);
                        $t_ref_msg_2 = str_replace('{soft_name}', settings('name'), $t_ref_msg_2);

                        if (checkAppMailEnvironment())
                        {
                            $this->email->sendEmail($requestpayment->receiver->email, $t_ref_sub_2, $t_ref_msg_2);
                        }

                        //sms
                        if (!empty($requestpayment->receiver->carrierCode) && !empty($requestpayment->receiver->phone))
                        {
                            if (!empty($rp_status_sms_info_suc_ref->subject) && !empty($rp_status_sms_info_suc_ref->body))
                            {
                                $rp_status_sms_info_suc_ref_sub = str_replace('{uuid}', $requestpayment->uuid, $rp_status_sms_info_suc_ref->subject);
                                $rp_status_sms_info_suc_ref_msg = str_replace('{user_id/receiver_id}', $requestpayment->receiver->first_name . ' ' . $requestpayment->receiver->last_name, $rp_status_sms_info_suc_ref->body);
                            }
                            else
                            {
                                $rp_status_sms_info_suc_ref_sub = str_replace('{uuid}', $requestpayment->uuid, $rp_status_en_sms_info_suc_ref->subject);
                                $rp_status_sms_info_suc_ref_msg = str_replace('{user_id/receiver_id}', $requestpayment->receiver->first_name . ' ' . $requestpayment->receiver->last_name, $rp_status_en_sms_info_suc_ref->body);
                            }
                            //4
                            $rp_status_sms_info_suc_ref_msg = str_replace('{uuid}', $requestpayment->uuid, $rp_status_sms_info_suc_ref_msg);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{status}', ($requestpayment->status == 'Blocked') ? "Cancelled" : (($requestpayment->status == 'Refund') ? "Refunded" : $requestpayment->status),
                                $rp_status_sms_info_suc_ref_msg);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{amount}', moneyFormat(optional($requestpayment->currency)->symbol, formatNumber($request->accept_amount + $request->charge_percentage + $request->charge_fixed)), $rp_status_sms_info_suc_ref_msg);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{added/subtracted}', 'added', $rp_status_sms_info_suc_ref_msg);
                            $rp_status_sms_info_suc_ref_msg = str_replace('{from/to}', 'to', $rp_status_sms_info_suc_ref_msg);

                            if (checkAppSmsEnvironment())
                            {
                                sendSMS($requestpayment->receiver->carrierCode . $requestpayment->receiver->phone, $rp_status_sms_info_suc_ref_msg);
                            }
                        }
                    }
                    $this->helper->one_time_message('success', __('The :x has been successfully saved.', ['x' => __('request payment')]));
                    return redirect(Config::get('adminPrefix').'/request_payments');
                }
            }
            elseif ($request->status == 'Blocked') //when current status is 'cancelled'
            {
                $request_created         = RequestPayment::find($request->id);
                $request_created->status = $request->status;
                $request_created->save();

                //Request From entry update
                Transaction::where([
                    'user_id'                  => $request->user_id,
                    'end_user_id'              => isset($userInfo) ? $userInfo->id : null,
                    'transaction_reference_id' => $request_created->id,
                    'transaction_type_id'      => Request_From,
                ])->update([
                    'status' => $request->status,
                ]);

                //Request To entry update
                Transaction::where([
                    'user_id'                  => isset($userInfo) ? $userInfo->id : null,
                    'end_user_id'              => $request->user_id,
                    'transaction_reference_id' => $request_created->id,
                    'transaction_type_id'      => Request_To,
                ])->update([
                    'status' => $request->status,
                ]);

                // Sent Mail when request is 'blocked'
                $t_block_temp = EmailTemplate::where([
                    'temp_id'     => 16,
                    'language_id' => Session::get('default_language'),
                    'type' => 'email',
                ])->select('subject', 'body')->first();

                // Creator Mail
                if (!empty($t_block_temp->subject) && !empty($t_block_temp->body))
                {
                    //Subject
                    $t_block_sub_1 = str_replace('{uuid}', $request_created->uuid, $t_block_temp->subject);
                    //Body
                    $t_block_msg_1 = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $t_block_temp->body);
                }
                else
                {
                    //Subject
                    $t_block_sub_1 = str_replace('{uuid}', $request_created->uuid, $englishSenderLanginfoForRPCancelPending->subject);
                    //Body
                    $t_block_msg_1 = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $englishSenderLanginfoForRPCancelPending->body);
                }
                //5
                $t_block_msg_1 = str_replace('{uuid}', $request_created->uuid, $t_block_msg_1);
                $t_block_msg_1 = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status), $t_block_msg_1);
                $t_block_msg_1 = str_replace('{soft_name}', settings('name'), $t_block_msg_1);

                if (checkAppMailEnvironment())
                {
                    $this->email->sendEmail($request_created->user->email, $t_block_sub_1, $t_block_msg_1);
                }

                //sms
                if (!empty($request_created->user->carrierCode) && !empty($request_created->user->phone))
                {
                    if (!empty($rp_status_sms_info_canc_pend->subject) && !empty($rp_status_sms_info_canc_pend->body))
                    {
                        $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend->subject);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $rp_status_sms_info_canc_pend->body);
                    }
                    else
                    {
                        $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_en_sms_info_canc_pend->subject);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $rp_status_en_sms_info_canc_pend->body);
                    }
                    //6
                    $rp_status_sms_info_canc_pend_msg = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend_msg);
                    $rp_status_sms_info_canc_pend_msg = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status),
                        $rp_status_sms_info_canc_pend_msg);

                    if (checkAppSmsEnvironment())
                    {
                        sendSMS($request_created->user->carrierCode . $request_created->user->phone, $rp_status_sms_info_canc_pend_msg);
                    }
                }

                if (isset($userInfo))
                {
                    // Receiver Mail
                    if (!empty($t_block_temp->subject) && !empty($t_block_temp->body))
                    {
                        //Subject
                        $t_block_sub_2 = str_replace('{uuid}', $request_created->uuid, $t_block_temp->subject);
                        //Body
                        $t_block_msg_2 = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $t_block_temp->body);
                    }
                    else
                    {
                        //Subject
                        $t_block_sub_2 = str_replace('{uuid}', $request_created->uuid, $englishSenderLanginfoForRPCancelPending->subject);
                        //Body
                        $t_block_msg_2 = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $englishSenderLanginfoForRPCancelPending->body);
                    }
                    //7
                    $t_block_msg_2 = str_replace('{uuid}', $request_created->uuid, $t_block_msg_2);
                    $t_block_msg_2 = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status), $t_block_msg_2);
                    $t_block_msg_2 = str_replace('{soft_name}', settings('name'), $t_block_msg_2);

                    if (checkAppMailEnvironment())
                    {
                        $this->email->sendEmail($request_created->receiver->email, $t_block_sub_2, $t_block_msg_2);
                    }

                    //sms
                    if (!empty($request_created->receiver->carrierCode) && !empty($request_created->receiver->phone))
                    {
                        if (!empty($rp_status_sms_info_canc_pend->subject) && !empty($rp_status_sms_info_canc_pend->body))
                        {
                            $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend->subject);
                            $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $rp_status_sms_info_canc_pend->body);
                        }
                        else
                        {
                            $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_en_sms_info_canc_pend->subject);
                            $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $rp_status_en_sms_info_canc_pend->body);
                        }
                        //8
                        $rp_status_sms_info_canc_pend_msg = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend_msg);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status),
                            $rp_status_sms_info_canc_pend_msg);

                        if (checkAppSmsEnvironment())
                        {
                            sendSMS($request_created->receiver->carrierCode . $request_created->receiver->phone, $rp_status_sms_info_canc_pend_msg);
                        }
                    }
                }
                $this->helper->one_time_message('success', __('The :x has been successfully saved.', ['x' => __('request payment')]));
                return redirect(Config::get('adminPrefix').'/request_payments');
            }
            elseif ($request->status == 'Pending') //when current status is 'pending'
            {
                $request_created         = RequestPayment::find($request->id);
                $request_created->status = $request->status;
                $request_created->save();

                //Request From entry update
                Transaction::where([
                    'user_id'                  => $request->user_id,
                    'end_user_id'              => isset($userInfo) ? $userInfo->id : null,
                    'transaction_reference_id' => $request_created->id,
                    'transaction_type_id'      => Request_From,
                ])->update([
                    'status' => $request->status,
                ]);

                //Request To entry update
                Transaction::where([
                    'user_id'                  => isset($userInfo) ? $userInfo->id : null,
                    'end_user_id'              => $request->user_id,
                    'transaction_reference_id' => $request_created->id,
                    'transaction_type_id'      => Request_To,
                ])->update([
                    'status' => $request->status,
                ]);

                // Sent Mail when request is 'Pending'
                $t_pending_temp_temp = EmailTemplate::where([
                    'temp_id'     => 16,
                    'language_id' => Session::get('default_language'),
                    'type' => 'email',
                ])->select('subject', 'body')->first();

                // Receiver Mail
                if (!empty($t_pending_temp_temp->subject) && !empty($t_pending_temp_temp->body))
                {
                    //Subject
                    $t_pending_sub_1 = str_replace('{uuid}', $request_created->uuid, $t_pending_temp_temp->subject);
                    //Body
                    $t_pending_msg_1 = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $t_pending_temp_temp->body);
                }
                else
                {
                    //Subject
                    $t_pending_sub_1 = str_replace('{uuid}', $request_created->uuid, $englishSenderLanginfoForRPCancelPending->subject);
                    //Body
                    $t_pending_msg_1 = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $englishSenderLanginfoForRPCancelPending->body);
                }
                //9
                $t_pending_msg_1 = str_replace('{uuid}', $request_created->uuid, $t_pending_msg_1);
                $t_pending_msg_1 = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status), $t_pending_msg_1);
                $t_pending_msg_1 = str_replace('{soft_name}', settings('name'), $t_pending_msg_1);

                if (checkAppMailEnvironment())
                {
                    $this->email->sendEmail($request_created->user->email, $t_pending_sub_1, $t_pending_msg_1);
                }

                //sms
                if (!empty($request_created->user->carrierCode) && !empty($request_created->user->phone))
                {
                    if (!empty($rp_status_sms_info_canc_pend->subject) && !empty($rp_status_sms_info_canc_pend->body))
                    {
                        $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend->subject);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $rp_status_sms_info_canc_pend->body);
                    }
                    else
                    {
                        $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_en_sms_info_canc_pend->subject);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->user->first_name . ' ' . $request_created->user->last_name, $rp_status_en_sms_info_canc_pend->body);
                    }
                    //10
                    $rp_status_sms_info_canc_pend_msg = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend_msg);
                    $rp_status_sms_info_canc_pend_msg = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status),
                        $rp_status_sms_info_canc_pend_msg);

                    if (checkAppSmsEnvironment())
                    {
                        sendSMS($request_created->user->carrierCode . $request_created->user->phone, $rp_status_sms_info_canc_pend_msg);
                    }
                }

                // if (isset($request_created->receiver))
                if (isset($userInfo))
                {
                    // Receiver Mail
                    if (!empty($t_pending_temp_temp->subject) && !empty($t_pending_temp_temp->body))
                    {
                        //Subject
                        $t_pending_sub_2 = str_replace('{uuid}', $request_created->uuid, $t_pending_temp_temp->subject);
                        //Body
                        $t_pending_msg_2 = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $t_pending_temp_temp->body);
                    }
                    else
                    {
                        //Subject
                        $t_pending_sub_2 = str_replace('{uuid}', $request_created->uuid, $englishSenderLanginfoForRPCancelPending->subject);
                        //Body
                        $t_pending_msg_2 = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $englishSenderLanginfoForRPCancelPending->body);
                    }
                    //11
                    $t_pending_msg_2 = str_replace('{uuid}', $request_created->uuid, $t_pending_msg_2);
                    $t_pending_msg_2 = str_replace('{status}', ($request_created->status == 'Blocked') ? 'Cancelled' : $request_created->status, $t_pending_msg_2);
                    $t_pending_msg_2 = str_replace('{soft_name}', settings('name'), $t_pending_msg_2);

                    if (checkAppMailEnvironment())
                    {
                        $this->email->sendEmail($request_created->receiver->email, $t_pending_sub_2, $t_pending_msg_2);
                    }

                    //sms
                    if (!empty($request_created->receiver->carrierCode) && !empty($request_created->receiver->phone))
                    {
                        if (!empty($rp_status_sms_info_canc_pend->subject) && !empty($rp_status_sms_info_canc_pend->body))
                        {
                            $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend->subject);
                            $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $rp_status_sms_info_canc_pend->body);
                        }
                        else
                        {
                            $rp_status_sms_info_canc_pend_sub = str_replace('{uuid}', $request_created->uuid, $rp_status_en_sms_info_canc_pend->subject);
                            $rp_status_sms_info_canc_pend_msg = str_replace('{user_id/receiver_id}', $request_created->receiver->first_name . ' ' . $request_created->receiver->last_name, $rp_status_en_sms_info_canc_pend->body);
                        }
                        //12
                        $rp_status_sms_info_canc_pend_msg = str_replace('{uuid}', $request_created->uuid, $rp_status_sms_info_canc_pend_msg);
                        $rp_status_sms_info_canc_pend_msg = str_replace('{status}', ($request_created->status == 'Blocked') ? "Cancelled" : (($request_created->status == 'Refund') ? "Refunded" : $request_created->status),
                            $rp_status_sms_info_canc_pend_msg);

                        if (checkAppSmsEnvironment())
                        {
                            sendSMS($request_created->receiver->carrierCode . $request_created->receiver->phone, $rp_status_sms_info_canc_pend_msg);
                        }
                    }
                }
                $this->helper->one_time_message('success', __('The :x has been successfully saved.', ['x' => __('request payment')]));
                return redirect(Config::get('adminPrefix').'/request_payments');
            }
        }
    }
}
