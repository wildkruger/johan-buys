<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as BaseModel;
use App\Traits\ModelTrait;

class Model extends BaseModel
{
    use ModelTrait;
}
