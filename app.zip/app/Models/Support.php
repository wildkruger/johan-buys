<?php

namespace App\Models;

use App\Models\Support;
use Illuminate\Database\Eloquent\Model;

class Support extends Model
{
    protected $table    = 'supports';
    public $timestamps = true;

}
