<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OauthPersonalAccessClient extends Model
{
    protected $table = 'oauth_personal_access_clients';
}
