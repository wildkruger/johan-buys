namespace App\Services;

class PaywebService
{
    public function initiateDeposit($apiCode, $amount)
    {
        // Implement Payweb API deposit logic here
    }

    public function initiateRefund($apiCode, $amount)
    {
        // Implement Payweb API refund logic here
    }
}
