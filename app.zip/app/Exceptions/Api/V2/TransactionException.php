<?php

/**
 * @package TransactionException
 * @author tehcvillage <support@techvill.org>
 * @contributor Md Abdur Rahaman <[abdur.techvill@gmail.com]>
 * @created 08-12-2022
 */

namespace App\Exceptions\Api\V2;
use Exception;

class TransactionException extends Exception
{
    //
}