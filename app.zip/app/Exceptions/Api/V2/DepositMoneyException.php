<?php

namespace App\Exceptions\Api\V2;

class DepositMoneyException extends ApiException
{
    //
}
