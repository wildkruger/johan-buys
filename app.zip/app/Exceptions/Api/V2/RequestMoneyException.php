<?php
namespace App\Exceptions\Api\V2;
use Exception;

class RequestMoneyException extends Exception
{
    //
}