<?php

/**
 * @package ExchangeMoneyException
 * @author tehcvillage <support@techvill.org>
 * @contributor Md Abdur Rahaman Zihad <[zihad.techvill@gmail.com]>
 * @created 03-12-2022
 */

namespace App\Exceptions\Api\V2;

class ExchangeMoneyException extends ApiException
{
    //
}
