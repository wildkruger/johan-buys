<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PAYMONEY_WOOCOMMERCE_ADDON_DIR . 'src/Rest/Connections.php';

class Paymoney_WoocommercePaymentGateway extends Connections
{
    public $paymoney_props = [];

    public function __construct($data = null)
    {
        parent::__construct();
        $paymoney_class = new \ReflectionClass($this);
        $paymoney_methods = $paymoney_class->getMethods();
        foreach ($paymoney_methods as $paymoney_method) {
            if ( !in_array($paymoney_method->name, $this->paymoney_props ) ) {
                $this->paymoney_props[$paymoney_method->name] = $paymoney_method->name;
            }
        }
    }
}