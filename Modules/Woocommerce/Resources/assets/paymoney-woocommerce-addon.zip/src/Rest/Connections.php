<?php

class Connections
{

    function __construct()
    {
        !defined('BASE_URL') ? define('BASE_URL', PAYMONEY_WOOCOMMERCE_BASE_URL) : false;
    }

    public function paymoney_execute($paymoney_url, $paymoney_method, $paymoney_payload, $paymoney_headers = null)
    {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $paymoney_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false
        ));
        if( strtoupper($paymoney_method) == "POST" ) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $paymoney_payload);
        }
        if( $paymoney_headers != null ) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $paymoney_headers);
        }
        $result = curl_exec($ch);
        $info =  curl_getinfo($ch, CURLINFO_HEADER_OUT);
        curl_close($ch);
        return $result;
    }
}